import { useState, useEffect } from 'react';
import { Cloud, CloudOff, RefreshCw, CheckCircle } from 'lucide-react';

interface SyncStatusProps {
  isOnline: boolean;
}

export default function SyncStatus({ isOnline }: SyncStatusProps) {
  const [lastSync, setLastSync] = useState<Date>(new Date());
  const [isSyncing, setIsSyncing] = useState(false);
  const [pendingRecords, setPendingRecords] = useState(1);

  const handleSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      setLastSync(new Date());
      setPendingRecords(0);
    }, 1500);
  };

  useEffect(() => {
    if (isOnline && pendingRecords > 0) {
      const timer = setTimeout(handleSync, 2000);
      return () => clearTimeout(timer);
    }
  }, [isOnline]);

  return (
    <div className={`mb-6 p-4 rounded-lg border-2 ${
      isOnline
        ? 'bg-green-50 border-green-200'
        : 'bg-orange-50 border-orange-200'
    }`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {isOnline ? (
            <Cloud className="w-5 h-5 text-green-600" />
          ) : (
            <CloudOff className="w-5 h-5 text-orange-600" />
          )}
          <div>
            <p className={`font-semibold ${
              isOnline ? 'text-green-900' : 'text-orange-900'
            }`}>
              {isOnline ? 'Connected to Server' : 'Working Offline'}
            </p>
            <p className={`text-sm ${
              isOnline ? 'text-green-700' : 'text-orange-700'
            }`}>
              {isOnline
                ? `Last synced: ${lastSync.toLocaleTimeString()}`
                : `${pendingRecords} record(s) pending sync`
              }
            </p>
          </div>
        </div>
        {isOnline && (
          <button
            onClick={handleSync}
            disabled={isSyncing}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-green-400 text-white rounded-lg font-medium transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            {isSyncing ? 'Syncing...' : 'Sync Now'}
          </button>
        )}
      </div>
      {!isOnline && (
        <div className="mt-3 pt-3 border-t border-orange-200">
          <p className="text-sm text-orange-700">
            <CheckCircle className="w-4 h-4 inline mr-1" />
            Data is being stored securely on your device. It will automatically sync when you're back online.
          </p>
        </div>
      )}
    </div>
  );
}

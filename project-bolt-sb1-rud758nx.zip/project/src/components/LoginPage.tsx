import { useState } from 'react';
import { LogIn, Users, UserCheck } from 'lucide-react';
import { UserRole, Language } from '../types';
import LanguageSwitcher from './LanguageSwitcher';

interface LoginPageProps {
  onLogin: (email: string, role: UserRole, language: Language) => void;
}

export default function LoginPage({ onLogin }: LoginPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole>('asha');
  const [language, setLanguage] = useState<Language>('en');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) {
      onLogin(email, selectedRole, language);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="inline-block p-4 bg-blue-600 rounded-2xl mb-4">
            <Users className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Sahayika App</h1>
          <p className="text-gray-600">Data Flow for ASHA Workers & PHC Staff</p>
          <div className="mt-4 flex justify-center">
            <LanguageSwitcher
              currentLanguage={language}
              onLanguageChange={setLanguage}
            />
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-800 font-medium">
              Demo Mode: Use any email and password to explore the platform!
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Role
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedRole('asha')}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    selectedRole === 'asha'
                      ? 'border-blue-600 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <UserCheck className={`w-8 h-8 mx-auto mb-2 ${
                    selectedRole === 'asha' ? 'text-blue-600' : 'text-gray-400'
                  }`} />
                  <div className="text-sm font-medium text-gray-900">ASHA Worker</div>
                  <div className="text-xs text-gray-500 mt-1">Field Data Collection</div>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedRole('phc')}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    selectedRole === 'phc'
                      ? 'border-green-600 bg-green-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <Users className={`w-8 h-8 mx-auto mb-2 ${
                    selectedRole === 'phc' ? 'text-green-600' : 'text-gray-400'
                  }`} />
                  <div className="text-sm font-medium text-gray-900">PHC Staff</div>
                  <div className="text-xs text-gray-500 mt-1">Dashboard & Reports</div>
                </button>
              </div>
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="demo@example.com"
                required
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter any password"
                required
              />
            </div>

            <button
              type="submit"
              className={`w-full py-3 px-4 rounded-lg font-medium text-white transition-colors flex items-center justify-center gap-2 ${
                selectedRole === 'asha'
                  ? 'bg-blue-600 hover:bg-blue-700'
                  : 'bg-green-600 hover:bg-green-700'
              }`}
            >
              <LogIn className="w-5 h-5" />
              Login as {selectedRole === 'asha' ? 'ASHA Worker' : 'PHC Staff'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

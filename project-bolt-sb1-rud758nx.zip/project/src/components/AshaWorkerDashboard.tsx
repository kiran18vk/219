import { useState } from 'react';
import { User, Visit, Reminder, Patient, Language } from '../types';
import {
  Users,
  FileText,
  Bell,
  Plus,
  LogOut,
  Wifi,
  WifiOff,
  Calendar,
  Activity,
  CheckCircle
} from 'lucide-react';
import PatientList from './PatientList';
import VisitRecorder from './VisitRecorder';
import RemindersList from './RemindersList';
import SyncStatus from './SyncStatus';
import LanguageSwitcher from './LanguageSwitcher';

interface AshaWorkerDashboardProps {
  user: User;
  onLogout: () => void;
}

export default function AshaWorkerDashboard({ user, onLogout }: AshaWorkerDashboardProps) {
  const [activeTab, setActiveTab] = useState<'patients' | 'visits' | 'reminders'>('patients');
  const [isOnline, setIsOnline] = useState(true);
  const [showNewVisit, setShowNewVisit] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [language, setLanguage] = useState<Language>(user.preferredLanguage || 'en');

  const tabs = [
    { id: 'patients' as const, label: 'Patients', icon: Users },
    { id: 'visits' as const, label: 'Record Visit', icon: FileText },
    { id: 'reminders' as const, label: 'Reminders', icon: Bell }
  ];

  const handleNewVisit = (patient: Patient) => {
    setSelectedPatient(patient);
    setShowNewVisit(true);
    setActiveTab('visits');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-600 rounded-lg">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">ASHA Worker Portal</h1>
                <p className="text-sm text-gray-600">{user.name}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <LanguageSwitcher
                currentLanguage={language}
                onLanguageChange={setLanguage}
              />
              <button
                onClick={() => setIsOnline(!isOnline)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium ${
                  isOnline
                    ? 'bg-green-100 text-green-700'
                    : 'bg-orange-100 text-orange-700'
                }`}
              >
                {isOnline ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
                {isOnline ? 'Online' : 'Offline'}
              </button>
              <button
                onClick={onLogout}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg text-gray-700 font-medium transition-colors"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <SyncStatus isOnline={isOnline} />

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="border-b border-gray-200">
            <nav className="flex">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex-1 px-6 py-4 text-sm font-medium transition-colors border-b-2 ${
                      activeTab === tab.id
                        ? 'border-blue-600 text-blue-600 bg-blue-50'
                        : 'border-transparent text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-5 h-5 inline-block mr-2" />
                    {tab.label}
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'patients' && (
              <PatientList onNewVisit={handleNewVisit} />
            )}
            {activeTab === 'visits' && (
              <VisitRecorder
                isOnline={isOnline}
                selectedPatient={selectedPatient}
                onPatientSelect={setSelectedPatient}
                language={language}
              />
            )}
            {activeTab === 'reminders' && (
              <RemindersList />
            )}
          </div>
        </div>

        {isOnline && (
          <div className="mt-6 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Activity className="w-5 h-5 text-blue-600" />
              Quick Stats
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Patients</p>
                    <p className="text-2xl font-bold text-gray-900">4</p>
                  </div>
                  <Users className="w-8 h-8 text-blue-600" />
                </div>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Visits Recorded</p>
                    <p className="text-2xl font-bold text-gray-900">3</p>
                  </div>
                  <FileText className="w-8 h-8 text-green-600" />
                </div>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Pending Reminders</p>
                    <p className="text-2xl font-bold text-gray-900">4</p>
                  </div>
                  <Bell className="w-8 h-8 text-orange-600" />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

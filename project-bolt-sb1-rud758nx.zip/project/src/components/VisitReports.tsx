import { useState } from 'react';
import { demoVisits } from '../demoData';
import { Visit } from '../types';
import { FileText, Calendar, User, Activity, CheckCircle, Clock } from 'lucide-react';

export default function VisitReports() {
  const [visits] = useState<Visit[]>(demoVisits);
  const [filter, setFilter] = useState<'all' | 'anc' | 'vaccination' | 'general'>('all');

  const filteredVisits = filter === 'all'
    ? visits
    : visits.filter(v => v.visitType === filter);

  const getVisitTypeColor = (type: string) => {
    switch (type) {
      case 'anc': return 'pink';
      case 'vaccination': return 'blue';
      case 'general': return 'green';
      default: return 'gray';
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Patient Visit Reports</h2>
        <div className="text-sm text-gray-600">
          Total: {filteredVisits.length} visit(s)
        </div>
      </div>

      <div className="mb-6 flex gap-2">
        {['all', 'anc', 'vaccination', 'general'].map((type) => (
          <button
            key={type}
            onClick={() => setFilter(type as any)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === type
                ? 'bg-green-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {type.charAt(0).toUpperCase() + type.slice(1)}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {filteredVisits.map((visit) => {
          const color = getVisitTypeColor(visit.visitType);

          return (
            <div
              key={visit.id}
              className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start gap-3">
                  <div className={`p-2 bg-${color}-100 rounded-lg`}>
                    <FileText className={`w-5 h-5 text-${color}-600`} />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">
                      {visit.patientName}
                    </h3>
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full bg-${color}-100 text-${color}-700`}>
                        {visit.visitType.toUpperCase()}
                      </span>
                      <span className={`flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full ${
                        visit.synced
                          ? 'bg-green-100 text-green-700'
                          : 'bg-orange-100 text-orange-700'
                      }`}>
                        {visit.synced ? (
                          <>
                            <CheckCircle className="w-3 h-3" />
                            Synced
                          </>
                        ) : (
                          <>
                            <Clock className="w-3 h-3" />
                            Pending Sync
                          </>
                        )}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right text-sm text-gray-600">
                  <div className="flex items-center gap-1 justify-end mb-1">
                    <Calendar className="w-4 h-4" />
                    {new Date(visit.date).toLocaleDateString('en-IN', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric'
                    })}
                  </div>
                  <div className="flex items-center gap-1 justify-end">
                    <User className="w-4 h-4" />
                    {visit.recordedBy}
                  </div>
                </div>
              </div>

              {visit.vitals && (
                <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                  <h4 className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                    <Activity className="w-4 h-4" />
                    Vital Signs
                  </h4>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    {visit.vitals.bloodPressure && (
                      <div>
                        <span className="text-gray-600">BP:</span>
                        <span className="ml-1 font-medium text-gray-900">{visit.vitals.bloodPressure}</span>
                      </div>
                    )}
                    {visit.vitals.temperature && (
                      <div>
                        <span className="text-gray-600">Temp:</span>
                        <span className="ml-1 font-medium text-gray-900">{visit.vitals.temperature}</span>
                      </div>
                    )}
                    {visit.vitals.weight && (
                      <div>
                        <span className="text-gray-600">Weight:</span>
                        <span className="ml-1 font-medium text-gray-900">{visit.vitals.weight}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-2">Visit Notes</h4>
                <p className="text-sm text-gray-600 leading-relaxed">{visit.notes}</p>
              </div>
            </div>
          );
        })}
      </div>

      {filteredVisits.length === 0 && (
        <div className="text-center py-12">
          <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No visits recorded yet.</p>
        </div>
      )}
    </div>
  );
}

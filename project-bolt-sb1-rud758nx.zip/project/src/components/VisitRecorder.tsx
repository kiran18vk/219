import { useState, useEffect } from 'react';
import { demoPatients } from '../demoData';
import { Patient, Language } from '../types';
import { Save, AlertCircle, CheckCircle, Mic, MicOff } from 'lucide-react';
import { useTranslation } from '../translations';

interface VisitRecorderProps {
  isOnline: boolean;
  selectedPatient: Patient | null;
  onPatientSelect: (patient: Patient | null) => void;
  language: Language;
}

export default function VisitRecorder({ isOnline, selectedPatient, onPatientSelect, language }: VisitRecorderProps) {
  const t = useTranslation(language);
  const [visitType, setVisitType] = useState<'anc' | 'vaccination' | 'general'>('general');
  const [notes, setNotes] = useState('');
  const [vitals, setVitals] = useState({
    bloodPressure: '',
    temperature: '',
    weight: ''
  });
  const [showSuccess, setShowSuccess] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognitionInstance = new SpeechRecognition();

      const languageMap: Record<Language, string> = {
        en: 'en-IN',
        hi: 'hi-IN',
        te: 'te-IN',
        ta: 'ta-IN',
        bn: 'bn-IN'
      };

      recognitionInstance.continuous = true;
      recognitionInstance.interimResults = true;
      recognitionInstance.lang = languageMap[language];

      recognitionInstance.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript + ' ';
          } else {
            interimTranscript += transcript;
          }
        }

        if (finalTranscript) {
          setNotes((prev) => prev + finalTranscript);
        }
      };

      recognitionInstance.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognitionInstance.onend = () => {
        setIsListening(false);
      };

      setRecognition(recognitionInstance);
    }
  }, [language]);

  const toggleVoiceInput = () => {
    if (!recognition) {
      alert('Voice input is not supported in your browser. Please use Chrome, Edge, or Safari.');
      return;
    }

    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      recognition.start();
      setIsListening(true);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (isListening) {
      recognition?.stop();
    }

    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
      setNotes('');
      setVitals({ bloodPressure: '', temperature: '', weight: '' });
      onPatientSelect(null);
    }, 2000);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-gray-900">{t('visit.record')}</h2>
        {!isOnline && (
          <div className="flex items-center gap-2 px-3 py-2 bg-orange-100 text-orange-700 rounded-lg text-sm">
            <AlertCircle className="w-4 h-4" />
            Data will be saved offline and synced later
          </div>
        )}
      </div>

      {showSuccess && (
        <div className="mb-6 p-4 bg-green-100 border border-green-300 rounded-lg flex items-center gap-3">
          <CheckCircle className="w-5 h-5 text-green-700" />
          <p className="text-green-700 font-medium">
            {t('visit.success')} {!isOnline && t('visit.offlineSuccess')}
          </p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('visit.selectPatient')}
          </label>
          <select
            value={selectedPatient?.id || ''}
            onChange={(e) => {
              const patient = demoPatients.find(p => p.id === e.target.value);
              onPatientSelect(patient || null);
            }}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            required
          >
            <option value="">{t('visit.choosePatient')}</option>
            {demoPatients.map((patient) => (
              <option key={patient.id} value={patient.id}>
                {patient.name} - {patient.village}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('visit.visitType')}
          </label>
          <div className="grid grid-cols-3 gap-3">
            {[
              { value: 'anc' as const, label: t('visit.anc'), color: 'pink' },
              { value: 'vaccination' as const, label: t('visit.vaccination'), color: 'blue' },
              { value: 'general' as const, label: t('visit.general'), color: 'green' }
            ].map((type) => (
              <button
                key={type.value}
                type="button"
                onClick={() => setVisitType(type.value)}
                className={`p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                  visitType === type.value
                    ? `border-${type.color}-600 bg-${type.color}-50 text-${type.color}-700`
                    : 'border-gray-200 text-gray-700 hover:border-gray-300'
                }`}
              >
                {type.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label htmlFor="bp" className="block text-sm font-medium text-gray-700 mb-2">
              {t('visit.bloodPressure')}
            </label>
            <input
              id="bp"
              type="text"
              placeholder="120/80"
              value={vitals.bloodPressure}
              onChange={(e) => setVitals({ ...vitals, bloodPressure: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label htmlFor="temp" className="block text-sm font-medium text-gray-700 mb-2">
              {t('visit.temperature')}
            </label>
            <input
              id="temp"
              type="text"
              placeholder="98.6°F"
              value={vitals.temperature}
              onChange={(e) => setVitals({ ...vitals, temperature: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label htmlFor="weight" className="block text-sm font-medium text-gray-700 mb-2">
              {t('visit.weight')}
            </label>
            <input
              id="weight"
              type="text"
              placeholder="60 kg"
              value={vitals.weight}
              onChange={(e) => setVitals({ ...vitals, weight: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
              {t('visit.notes')}
            </label>
            <button
              type="button"
              onClick={toggleVoiceInput}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                isListening
                  ? 'bg-red-600 hover:bg-red-700 text-white animate-pulse'
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
            >
              {isListening ? (
                <>
                  <MicOff className="w-4 h-4" />
                  {t('visit.stopRecording')}
                </>
              ) : (
                <>
                  <Mic className="w-4 h-4" />
                  {t('visit.voiceInput')}
                </>
              )}
            </button>
          </div>
          {isListening && (
            <div className="mb-2 p-3 bg-blue-50 border border-blue-200 rounded-lg flex items-center gap-2">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
              </div>
              <span className="text-sm text-blue-700 font-medium">{t('visit.listening')}</span>
            </div>
          )}
          <textarea
            id="notes"
            rows={6}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder={t('visit.notesPlaceholder')}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            required
          />
        </div>

        <div className="flex gap-3">
          <button
            type="submit"
            disabled={!selectedPatient}
            className="flex-1 py-3 px-6 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
          >
            <Save className="w-5 h-5" />
            {isOnline ? t('visit.saveSync') : t('visit.saveOffline')}
          </button>
        </div>
      </form>
    </div>
  );
}

import { demoPatients, demoVisits, demoReminders } from '../demoData';
import { BarChart3, TrendingUp, Users, MapPin, Calendar } from 'lucide-react';

export default function PatientAnalytics() {
  const totalPatients = demoPatients.length;
  const totalVisits = demoVisits.length;
  const pendingReminders = demoReminders.filter(r => !r.completed).length;

  const visitsByType = {
    anc: demoVisits.filter(v => v.visitType === 'anc').length,
    vaccination: demoVisits.filter(v => v.visitType === 'vaccination').length,
    general: demoVisits.filter(v => v.visitType === 'general').length,
  };

  const patientsByVillage = demoPatients.reduce((acc, patient) => {
    acc[patient.village] = (acc[patient.village] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const patientsByGender = {
    male: demoPatients.filter(p => p.gender === 'male').length,
    female: demoPatients.filter(p => p.gender === 'female').length,
    other: demoPatients.filter(p => p.gender === 'other').length,
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Patient Analytics & Insights</h2>
        <div className="text-sm text-gray-600">
          Data updated in real-time
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="border border-gray-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-600" />
            Visits by Type
          </h3>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">ANC Visits</span>
                <span className="text-sm font-bold text-gray-900">{visitsByType.anc}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-pink-500 h-3 rounded-full"
                  style={{ width: `${(visitsByType.anc / totalVisits) * 100}%` }}
                ></div>
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Vaccination</span>
                <span className="text-sm font-bold text-gray-900">{visitsByType.vaccination}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-blue-500 h-3 rounded-full"
                  style={{ width: `${(visitsByType.vaccination / totalVisits) * 100}%` }}
                ></div>
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">General Checkup</span>
                <span className="text-sm font-bold text-gray-900">{visitsByType.general}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-green-500 h-3 rounded-full"
                  style={{ width: `${(visitsByType.general / totalVisits) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        <div className="border border-gray-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-green-600" />
            Patients by Village
          </h3>
          <div className="space-y-4">
            {Object.entries(patientsByVillage).map(([village, count]) => (
              <div key={village}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">{village}</span>
                  <span className="text-sm font-bold text-gray-900">{count}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div
                    className="bg-green-500 h-3 rounded-full"
                    style={{ width: `${(count / totalPatients) * 100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="border border-gray-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-orange-600" />
            Patient Demographics
          </h3>
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Male Patients</p>
              <p className="text-2xl font-bold text-gray-900">{patientsByGender.male}</p>
              <p className="text-xs text-gray-500 mt-1">
                {((patientsByGender.male / totalPatients) * 100).toFixed(1)}% of total
              </p>
            </div>
            <div className="p-4 bg-pink-50 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Female Patients</p>
              <p className="text-2xl font-bold text-gray-900">{patientsByGender.female}</p>
              <p className="text-xs text-gray-500 mt-1">
                {((patientsByGender.female / totalPatients) * 100).toFixed(1)}% of total
              </p>
            </div>
          </div>
        </div>

        <div className="border border-gray-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            Key Metrics
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg text-white">
              <div>
                <p className="text-sm opacity-90 mb-1">Total Patients</p>
                <p className="text-3xl font-bold">{totalPatients}</p>
              </div>
              <Users className="w-10 h-10 opacity-70" />
            </div>
            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-green-500 to-green-600 rounded-lg text-white">
              <div>
                <p className="text-sm opacity-90 mb-1">Total Visits</p>
                <p className="text-3xl font-bold">{totalVisits}</p>
              </div>
              <Calendar className="w-10 h-10 opacity-70" />
            </div>
            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg text-white">
              <div>
                <p className="text-sm opacity-90 mb-1">Active Reminders</p>
                <p className="text-3xl font-bold">{pendingReminders}</p>
              </div>
              <TrendingUp className="w-10 h-10 opacity-70" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

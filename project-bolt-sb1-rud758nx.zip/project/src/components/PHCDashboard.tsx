import { useState } from 'react';
import { User } from '../types';
import {
  BarChart3,
  FileText,
  Users,
  Activity,
  LogOut,
  TrendingUp,
  AlertCircle,
  Calendar
} from 'lucide-react';
import VisitReports from './VisitReports';
import PatientAnalytics from './PatientAnalytics';

interface PHCDashboardProps {
  user: User;
  onLogout: () => void;
}

export default function PHCDashboard({ user, onLogout }: PHCDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'reports' | 'analytics'>('overview');

  const tabs = [
    { id: 'overview' as const, label: 'Overview', icon: Activity },
    { id: 'reports' as const, label: 'Visit Reports', icon: FileText },
    { id: 'analytics' as const, label: 'Analytics', icon: BarChart3 }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-600 rounded-lg">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">PHC Staff Portal</h1>
                <p className="text-sm text-gray-600">{user.name}</p>
              </div>
            </div>
            <button
              onClick={onLogout}
              className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg text-gray-700 font-medium transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="border-b border-gray-200">
            <nav className="flex">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex-1 px-6 py-4 text-sm font-medium transition-colors border-b-2 ${
                      activeTab === tab.id
                        ? 'border-green-600 text-green-600 bg-green-50'
                        : 'border-transparent text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-5 h-5 inline-block mr-2" />
                    {tab.label}
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'overview' && (
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Dashboard Overview</h2>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                  <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white">
                    <Users className="w-8 h-8 mb-3 opacity-80" />
                    <p className="text-3xl font-bold mb-1">4</p>
                    <p className="text-blue-100 text-sm">Total Patients</p>
                  </div>
                  <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white">
                    <FileText className="w-8 h-8 mb-3 opacity-80" />
                    <p className="text-3xl font-bold mb-1">3</p>
                    <p className="text-green-100 text-sm">Visits This Week</p>
                  </div>
                  <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl p-6 text-white">
                    <AlertCircle className="w-8 h-8 mb-3 opacity-80" />
                    <p className="text-3xl font-bold mb-1">4</p>
                    <p className="text-orange-100 text-sm">Pending Reminders</p>
                  </div>
                  <div className="bg-gradient-to-br from-pink-500 to-pink-600 rounded-xl p-6 text-white">
                    <TrendingUp className="w-8 h-8 mb-3 opacity-80" />
                    <p className="text-3xl font-bold mb-1">2</p>
                    <p className="text-pink-100 text-sm">Active ANC Cases</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="border border-gray-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                      <Calendar className="w-5 h-5 text-green-600" />
                      Recent Activity
                    </h3>
                    <div className="space-y-3">
                      <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <div className="w-2 h-2 rounded-full bg-green-500 mt-2"></div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">ANC Visit Recorded</p>
                          <p className="text-xs text-gray-600">Priya Sharma - 2 days ago</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <div className="w-2 h-2 rounded-full bg-blue-500 mt-2"></div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">ANC Visit Recorded</p>
                          <p className="text-xs text-gray-600">Anita Devi - 3 days ago</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <div className="w-2 h-2 rounded-full bg-orange-500 mt-2"></div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">General Checkup</p>
                          <p className="text-xs text-gray-600">Rajesh Kumar - 4 days ago</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                      <AlertCircle className="w-5 h-5 text-orange-600" />
                      Upcoming Actions
                    </h3>
                    <div className="space-y-3">
                      <div className="p-3 bg-pink-50 border border-pink-200 rounded-lg">
                        <p className="text-sm font-medium text-gray-900">ANC Follow-up Due</p>
                        <p className="text-xs text-gray-600 mt-1">Anita Devi - Nov 1, 2024</p>
                      </div>
                      <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <p className="text-sm font-medium text-gray-900">Vaccination Reminder</p>
                        <p className="text-xs text-gray-600 mt-1">Meena Singh - Oct 15, 2024</p>
                      </div>
                      <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                        <p className="text-sm font-medium text-gray-900">Follow-up Visit</p>
                        <p className="text-xs text-gray-600 mt-1">Rajesh Kumar - Oct 10, 2024</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'reports' && <VisitReports />}
            {activeTab === 'analytics' && <PatientAnalytics />}
          </div>
        </div>
      </div>
    </div>
  );
}

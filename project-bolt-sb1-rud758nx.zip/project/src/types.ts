export type UserRole = 'asha' | 'phc';
export type Language = 'en' | 'hi' | 'te' | 'ta' | 'bn';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  name: string;
  preferredLanguage?: Language;
}

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  village: string;
  phoneNumber: string;
  address: string;
  createdAt: string;
  createdBy: string;
}

export interface Visit {
  id: string;
  patientId: string;
  patientName: string;
  visitType: 'anc' | 'vaccination' | 'general';
  date: string;
  notes: string;
  vitals?: {
    bloodPressure?: string;
    temperature?: string;
    weight?: string;
  };
  synced: boolean;
  recordedBy: string;
  recordedAt: string;
}

export interface Reminder {
  id: string;
  patientId: string;
  patientName: string;
  type: 'anc' | 'vaccination' | 'followup';
  dueDate: string;
  message: string;
  completed: boolean;
}

export interface SyncStatus {
  lastSyncTime: string | null;
  pendingRecords: number;
  isOnline: boolean;
}

import { useState } from 'react';
import { User, UserRole, Language } from './types';
import LoginPage from './components/LoginPage';
import AshaWorkerDashboard from './components/AshaWorkerDashboard';
import PHCDashboard from './components/PHCDashboard';

function App() {
  const [user, setUser] = useState<User | null>(null);

  const handleLogin = (email: string, role: UserRole, language: Language) => {
    const newUser: User = {
      id: Math.random().toString(36).substring(7),
      email,
      role,
      name: role === 'asha' ? 'ASHA Worker 1' : 'Dr. Sharma (PHC Staff)',
      preferredLanguage: language
    };
    setUser(newUser);
  };

  const handleLogout = () => {
    setUser(null);
  };

  if (!user) {
    return <LoginPage onLogin={handleLogin} />;
  }

  if (user.role === 'asha') {
    return <AshaWorkerDashboard user={user} onLogout={handleLogout} />;
  }

  return <PHCDashboard user={user} onLogout={handleLogout} />;
}

export default App;

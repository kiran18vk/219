import { Patient, Visit, Reminder } from './types';

export const demoPatients: Patient[] = [
  {
    id: '1',
    name: 'Priya Sharma',
    age: 28,
    gender: 'female',
    village: 'Rampur',
    phoneNumber: '+91 98765 43210',
    address: 'House No. 45, Rampur Village',
    createdAt: '2024-09-15T10:30:00Z',
    createdBy: 'ASHA Worker 1'
  },
  {
    id: '2',
    name: 'Rajesh Kumar',
    age: 35,
    gender: 'male',
    village: 'Sundarpur',
    phoneNumber: '+91 98765 43211',
    address: 'House No. 12, Sundarpur Village',
    createdAt: '2024-09-20T14:20:00Z',
    createdBy: 'ASHA Worker 1'
  },
  {
    id: '3',
    name: 'Anita Devi',
    age: 24,
    gender: 'female',
    village: 'Rampur',
    phoneNumber: '+91 98765 43212',
    address: 'House No. 78, Rampur Village',
    createdAt: '2024-10-01T09:15:00Z',
    createdBy: 'ASHA Worker 2'
  },
  {
    id: '4',
    name: 'Meena Singh',
    age: 32,
    gender: 'female',
    village: 'Greenfield',
    phoneNumber: '+91 98765 43213',
    address: 'House No. 23, Greenfield Village',
    createdAt: '2024-10-03T11:45:00Z',
    createdBy: 'ASHA Worker 1'
  }
];

export const demoVisits: Visit[] = [
  {
    id: '1',
    patientId: '1',
    patientName: 'Priya Sharma',
    visitType: 'anc',
    date: '2024-10-05T10:00:00Z',
    notes: 'First ANC visit. Patient is healthy. Prescribed folic acid and iron supplements.',
    vitals: {
      bloodPressure: '120/80',
      temperature: '98.6°F',
      weight: '58 kg'
    },
    synced: true,
    recordedBy: 'ASHA Worker 1',
    recordedAt: '2024-10-05T10:30:00Z'
  },
  {
    id: '2',
    patientId: '3',
    patientName: 'Anita Devi',
    visitType: 'anc',
    date: '2024-10-04T14:00:00Z',
    notes: 'Second ANC visit. All tests normal. Scheduled next visit in 4 weeks.',
    vitals: {
      bloodPressure: '118/76',
      temperature: '98.4°F',
      weight: '62 kg'
    },
    synced: false,
    recordedBy: 'ASHA Worker 2',
    recordedAt: '2024-10-04T14:25:00Z'
  },
  {
    id: '3',
    patientId: '2',
    patientName: 'Rajesh Kumar',
    visitType: 'general',
    date: '2024-10-03T09:30:00Z',
    notes: 'General health checkup. Patient complained of mild fever. Advised rest and hydration.',
    vitals: {
      bloodPressure: '130/85',
      temperature: '99.2°F',
      weight: '72 kg'
    },
    synced: true,
    recordedBy: 'ASHA Worker 1',
    recordedAt: '2024-10-03T10:00:00Z'
  }
];

export const demoReminders: Reminder[] = [
  {
    id: '1',
    patientId: '1',
    patientName: 'Priya Sharma',
    type: 'anc',
    dueDate: '2024-11-05',
    message: 'Second ANC visit scheduled. Blood tests required.',
    completed: false
  },
  {
    id: '2',
    patientId: '3',
    patientName: 'Anita Devi',
    type: 'anc',
    dueDate: '2024-11-01',
    message: 'Third ANC visit. Ultrasound scheduled.',
    completed: false
  },
  {
    id: '3',
    patientId: '4',
    patientName: 'Meena Singh',
    type: 'vaccination',
    dueDate: '2024-10-15',
    message: 'Child vaccination due - DPT 2nd dose.',
    completed: false
  },
  {
    id: '4',
    patientId: '2',
    patientName: 'Rajesh Kumar',
    type: 'followup',
    dueDate: '2024-10-10',
    message: 'Follow-up visit for fever. Check temperature.',
    completed: false
  }
];
